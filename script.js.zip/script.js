// A. TOGGLE DARK MODE
const themeBtn = document.getElementById("themeBtn");
themeBtn.addEventListener("click", () => {
document.body.classList.toggle("dark-mode");
});


// B. EDIT JOB TITLE
const editJobBtn = document.getElementById("editJobBtn");
const jobTitle = document.getElementById("jobTitle");


editJobBtn.addEventListener("click", () => {
const newTitle = prompt("Enter your new job title:");
if (newTitle) {
jobTitle.textContent = newTitle;
}
});


// C. SHOW / HIDE SKILLS
const toggleSkillsBtn = document.getElementById("toggleSkillsBtn");
const skillsSection = document.getElementById("skillsSection");


let skillsVisible = true;


toggleSkillsBtn.addEventListener("click", () => {
if (skillsVisible) {
skillsSection.style.display = "none";
toggleSkillsBtn.textContent = "Show Skills";
} else {
skillsSection.style.display = "block";
toggleSkillsBtn.textContent = "Hide Skills";
}
skillsVisible = !skillsVisible;
});


// D. LIVE CHARACTER COUNTER
const msgBox = document.getElementById("msgBox");
const counter = document.getElementById("counter");


msgBox.addEventListener("keyup", () => {
const remaining = 200 - msgBox.value.length;
counter.textContent = remaining;
});


// E. FORM VALIDATION
function validateForm() {
const name = document.getElementById("nameField").value;
const email = document.getElementById("emailField").value;


if (name === "" || email === "") {
alert("Please fill in both Name and Email fields.");
return false;
}
alert("Form submitted successfully!");
return true;
}


// F. DISPLAY TODAY'S DATE
const dateDisplay = document.getElementById("dateDisplay");
const today = new Date();
dateDisplay.textContent = "Today's Date: " + today.toDateString();


// G. EXTRA FEATURE: GREETING BASED ON TIME
const greeting = document.getElementById("greeting");
const hour = new Date().getHours();


if (hour < 12) {
greeting.textContent = "Good Morning!";
} else if (hour < 18) {
greeting.textContent = "Good Afternoon!";
} else {
greeting.textContent = "Good Evening!";
}


// EXTRA: PROFILE IMAGE SWITCHER
const changePicBtn = document.getElementById("changePicBtn");
const profilePic = document.getElementById("profilePic");


changePicBtn.addEventListener("click", () => {
profilePic.src = "https://via.placeholder.com/150/0000FF/FFFFFF";
});